﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using _999.Models;

namespace _999.Controllers
{
    public class BookController : Controller
    {
        // GET: /Book/Index
        public IActionResult Index()
        {
            var books = GetBooks();
            return View("Index", books);
        }

        // POST: /Book/AddToCart/1
        [HttpPost]
        public IActionResult AddToCart(int id)
        {
            List<int> cart = HttpContext.Session.GetString("Cart") != null ?
                JsonConvert.DeserializeObject<List<int>>(HttpContext.Session.GetString("Cart")) :
                new List<int>();

            cart.Add(id);
            HttpContext.Session.SetString("Cart", JsonConvert.SerializeObject(cart));

            return RedirectToAction("Index", "Book");
        }

        // GET: /Book/Cart
        public IActionResult Cart()
        {
            List<int> cart = HttpContext.Session.GetString("Cart") != null ?
                JsonConvert.DeserializeObject<List<int>>(HttpContext.Session.GetString("Cart")) :
                new List<int>();

            List<CartItem> cartItems = new List<CartItem>(); // Объявляем здесь

            foreach (var bookId in cart)
            {
                var book = GetBookById(bookId);
                if (book != null)
                {
                    cartItems.Add(new CartItem
                    {
                        Id = book.Id,
                        Name = book.Name, // Замените book.Name на book.Title
                        Price = book.Price,
                        Author = book.Author,
                        ImageUrl = book.ImageUrl
                    });
                }
            }

            return View("Cart", cartItems);
        }

        // Метод для получения списка книг (заглушка)
        private List<BookViewModel> GetBooks()
        {
            return new List<BookViewModel>
    {
        new BookViewModel(1, "Война и мир", "Лев Толстой", 999, "/images/voyna_i_mir.jpg"),
        new BookViewModel(2, "Преступление и наказание", "Федор Достоевский", 799, "/images/prestuplenie_i_nakazanie.jpg"),
        new BookViewModel(3, "Мастер и Маргарита", "Михаил Булгаков", 899, "/images/master_i_margarita.jpg"),
        new BookViewModel(4, "Анна Каренина", "Лев Толстой", 899, "/images/anna_karenina.jpg"),
        new BookViewModel(5, "1984", "Джордж Оруэлл", 599, "/images/1984.jpg"),
        new BookViewModel(6, "Три товарища", "Эрих Мария Ремарк", 699, "/images/tri_tovarishcha.jpg"),
        new BookViewModel(7, "Алиса в стране чудес", "Льюис Кэрролл", 399, "/images/alisa_v_strane_chudes.jpg"),
        new BookViewModel(8, "Гарри Поттер и философский камень", "Джоан Роулинг", 799, "/images/harry_potter_i_filosofskii_kamen.jpg"),
        new BookViewModel(9, "Идиот", "Федор Достоевский", 899, "/images/idiot.jpg"),
        new BookViewModel(10, "Гордость и предубеждение", "Джейн Остин", 749, "/images/gordost_i_predubezhdenie.jpg")
    };
        }


        // Метод для получения книги по идентификатору (заглушка)
        private BookViewModel GetBookById(int id)
        {
            var books = GetBooks();
            return books.FirstOrDefault(book => book.Id == id);
        }
    }
}
