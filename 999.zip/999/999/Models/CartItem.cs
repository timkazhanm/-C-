﻿using System; // Добавлено пространство имен

namespace _999.Models
{
    public class CartItem
    {
        public int Id { get; set; } // Уникальный идентификатор товара
        public string Name { get; set; } // Название товара
        public decimal Price { get; set; } // Цена товара
        public string Author { get; set; } // Автор книги
        public string ImageUrl { get; set; } // URL изображения товара
    }
} // Добавлена закрывающая фигурная скобка
