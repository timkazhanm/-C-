﻿using System.Collections.Generic;

public class BookViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } // Добавлено свойство Name
    public string Author { get; set; }
    public int Price { get; set; }
    public string ImageUrl { get; set; }

    // Конструктор для создания экземпляра класса с использованием параметров
    public BookViewModel(int id, string name, string author, int price, string imageUrl)
    {
        Id = id;
        Name = name;
        Author = author;
        Price = price;
        ImageUrl = imageUrl;
    }

    // Метод для получения списка книг (заглушка)
    public static List<BookViewModel> GetBooks()
    {
        return new List<BookViewModel>
        {
        new BookViewModel(1, "Война и мир", "Лев Толстой", 999, "/images/voyna_i_mir.jpg"),
        new BookViewModel(2, "Преступление и наказание", "Федор Достоевский", 799, "/images/prestuplenie_i_nakazanie.jpg"),
        new BookViewModel(3, "Мастер и Маргарита", "Михаил Булгаков", 899, "/images/master_i_margarita.jpg"),
        new BookViewModel(4, "Анна Каренина", "Лев Толстой", 899, "/images/anna_karenina.jpg"),
        new BookViewModel(5, "1984", "Джордж Оруэлл", 599, "/images/1984.jpg"),
        new BookViewModel(6, "Три товарища", "Эрих Мария Ремарк", 699, "/images/tri_tovarishcha.jpg"),
        new BookViewModel(7, "Алиса в стране чудес", "Льюис Кэрролл", 399, "/images/alisa_v_strane_chudes.jpg"),
        new BookViewModel(8, "Гарри Поттер и философский камень", "Джоан Роулинг", 799, "/images/harry_potter_i_filosofskii_kamen.jpg"),
        new BookViewModel(9, "Идиот", "Федор Достоевский", 899, "/images/idiot.jpg"),
        new BookViewModel(10, "Гордость и предубеждение", "Джейн Остин", 749, "/images/gordost_i_predubezhdenie.jpg")
        };
    }
}
